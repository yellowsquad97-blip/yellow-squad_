package com.yellowsquad.yellowclient

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("yellow_client", Context.MODE_PRIVATE) }
    private lateinit var command: EditText
    private lateinit var interval: EditText
    private lateinit var armor: EditText
    private lateinit var hudSwitch: Switch
    private lateinit var reminderSwitch: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(15, 15, 15))
        }
        fun text(value: String, size: Float = 15f) = TextView(this).apply {
            text = value; textSize = size; setTextColor(Color.rgb(255, 212, 0))
        }
        fun edit(hintText: String, value: String): EditText = EditText(this).apply {
            hint = hintText; setSingleLine(true); setText(value)
            setTextColor(Color.WHITE); setHintTextColor(0xFF999999.toInt())
            setPadding(14, 8, 14, 8)
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFFFFD400.toInt())
        }
        root.addView(text("YELLOW CLIENT", 27f))
        root.addView(TextView(this).apply {
            text = "BEDROCK 1.21.51  •  ANDROID\nپنل شناور شخصی‌سازی‌شونده"
            textSize = 13f; setTextColor(0xFFCCCCCC.toInt())
        })
        root.addView(text("\nمیانبر کامند"))
        command = edit("مثلاً /spawn", prefs.getString("command", "/spawn") ?: "/spawn")
        root.addView(command)
        root.addView(text("فاصله هشدار زره (دقیقه)"))
        interval = edit("5", prefs.getInt("interval", 5).toString())
        root.addView(interval)
        root.addView(text("درصد نمایشی زره (۰ تا ۱۰۰)"))
        armor = edit("100", prefs.getInt("armor", 100).toString())
        root.addView(armor)
        hudSwitch = Switch(this).apply {
            text = "نمایش Armor HUD (دستی/نمایشی)"; setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("hud", true)
        }
        root.addView(hudSwitch)
        reminderSwitch = Switch(this).apply {
            text = "فعال‌بودن یادآور زره"; setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("reminder", true)
        }
        root.addView(reminderSwitch)

        root.addView(Button(this).apply {
            text = "ذخیره تنظیمات"
            setOnClickListener {
                val mins = interval.text.toString().toIntOrNull()?.coerceIn(1, 240) ?: 5
                val durability = armor.text.toString().toIntOrNull()?.coerceIn(0, 100) ?: 100
                interval.setText(mins.toString()); armor.setText(durability.toString())
                prefs.edit().putString("command", command.text.toString().trim().ifBlank { "/spawn" })
                    .putInt("interval", mins).putInt("armor", durability)
                    .putBoolean("hud", hudSwitch.isChecked)
                    .putBoolean("reminder", reminderSwitch.isChecked).apply()
                Toast.makeText(this@MainActivity, "تنظیمات ذخیره شد", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "فعال‌کردن پنل شناور روی بازی"
            setOnClickListener {
                saveSettings()
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(Intent(this@MainActivity, OverlayService::class.java))
                    else startService(Intent(this@MainActivity, OverlayService::class.java))
                    Toast.makeText(this@MainActivity, "پنل فعاله؛ حالا Minecraft رو باز کن", Toast.LENGTH_LONG).show()
                }
            }
        })
        root.addView(Button(this).apply {
            text = "خاموش‌کردن پنل"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
        root.addView(TextView(this).apply {
            text = "\nراهنما و محدودیت‌ها\n• دکمه کامند، متن ذخیره‌شده را کپی می‌کند؛ چت Minecraft را باز کن و Paste/Send بزن. برنامه عادی اندروید نمی‌تواند کامند را بی‌واسطه به سرور بفرستد.\n• Armor HUD این نسخه دستی/نمایشی است و درصد واقعی زره را از بازی نمی‌خواند.\n• برای جابه‌جایی، دکمه Y یا نوار عنوان پنل را بکش."
            textSize = 13f; setTextColor(0xFFBBBBBB.toInt())
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun saveSettings() {
        val mins = interval.text.toString().toIntOrNull()?.coerceIn(1, 240) ?: 5
        val durability = armor.text.toString().toIntOrNull()?.coerceIn(0, 100) ?: 100
        prefs.edit().putString("command", command.text.toString().trim().ifBlank { "/spawn" })
            .putInt("interval", mins).putInt("armor", durability)
            .putBoolean("hud", hudSwitch.isChecked)
            .putBoolean("reminder", reminderSwitch.isChecked).apply()
    }
}
