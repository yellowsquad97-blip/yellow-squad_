package com.yellowsquad.yellowclient

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.widget.*
import android.content.ClipData
import android.content.ClipboardManager
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val prefs by lazy { getSharedPreferences("yellow_client", Context.MODE_PRIVATE) }
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var armorView: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val reminder = object : Runnable {
        override fun run() {
            if (prefs.getBoolean("reminder", true)) {
                Toast.makeText(this@OverlayService, "Yellow Client • زره‌هات رو چک کن! 🛡", Toast.LENGTH_LONG).show()
            }
            handler.postDelayed(this, prefs.getInt("interval", 5).coerceIn(1, 240) * 60 * 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(7, makeNotification())
        showBubble()
        if (prefs.getBoolean("hud", true)) showArmorHud()
        handler.postDelayed(reminder, prefs.getInt("interval", 5).coerceIn(1, 240) * 60 * 1000L)
    }

    private fun makeNotification(): Notification {
        val id = "yellow_client_overlay"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(id, "Yellow Client overlay", NotificationManager.IMPORTANCE_LOW))
            return Notification.Builder(this, id).setContentTitle("Yellow Client فعال است")
                .setContentText("پنل شناور اجرا می‌شود").setSmallIcon(android.R.drawable.ic_menu_view).build()
        }
        @Suppress("DEPRECATION")
        return Notification.Builder(this).setContentTitle("Yellow Client فعال است")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
    }

    private fun params(x: Int, y: Int, w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun makeDraggable(view: View, saveKey: String? = null) {
        view.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val p = v.layoutParams as WindowManager.LayoutParams
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt()
                        if (abs(dx)>7 || abs(dy)>7) moved=true
                        p.x=ox+dx; p.y=oy+dy
                        try { wm.updateViewLayout(v,p) } catch (_: Exception) {}
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (saveKey != null) prefs.edit().putInt("${saveKey}_x", p.x).putInt("${saveKey}_y", p.y).apply()
                        if (!moved) v.performClick()
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "Y"; textSize = 22f; gravity = Gravity.CENTER
            setTextColor(Color.BLACK); setBackgroundColor(0xFFFFD400.toInt())
            elevation = 12f
            setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        }
        bubble = b
        wm.addView(b, params(prefs.getInt("bubble_x", 18), prefs.getInt("bubble_y", 220), 58, 58))
        makeDraggable(b, "bubble")
    }

    private fun showArmorHud() {
        val value = prefs.getInt("armor", 100).coerceIn(0, 100)
        val hud = TextView(this).apply {
            text = "🛡 ARMOR\n${value}%"
            textSize = 14f; setTextColor(0xFFFFD400.toInt()); setPadding(12, 10, 12, 10)
            setBackgroundColor(0xDD111111.toInt())
        }
        armorView = hud
        wm.addView(hud, params(prefs.getInt("armor_x", 250), prefs.getInt("armor_y", 170), WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT))
        makeDraggable(hud, "armor")
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(12, 10, 12, 10)
            setBackgroundColor(0xF2111111.toInt())
        }
        val title = TextView(this).apply {
            text = "YELLOW CLIENT  ✦  بکش برای جابه‌جایی"; textSize = 14f
            setTextColor(0xFFFFD400.toInt()); setPadding(4, 6, 4, 8)
        }
        box.addView(title)
        title.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var ox=0; var oy=0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val p=box.layoutParams as WindowManager.LayoutParams
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; return true }
                    MotionEvent.ACTION_MOVE -> { p.x=ox+(e.rawX-sx).toInt(); p.y=oy+(e.rawY-sy).toInt(); wm.updateViewLayout(box,p); return true }
                    MotionEvent.ACTION_UP -> { prefs.edit().putInt("panel_x",p.x).putInt("panel_y",p.y).apply(); return true }
                }; return false
            }
        })
        val armor = TextView(this).apply {
            text = "🛡 Armor HUD  •  ${prefs.getInt("armor",100).coerceIn(0,100)}%\n(مقدار دستی/نمایشی)"
            setTextColor(Color.WHITE); textSize=13f; setPadding(4,4,4,8)
        }
        box.addView(armor)
        fun button(label: String, action: () -> Unit) {
            box.addView(Button(this).apply { text=label; setOnClickListener { action() } })
        }
        button("▶ اجرای کامند ذخیره‌شده") {
            val cmd=prefs.getString("command","/spawn") ?: "/spawn"
            val clipboard=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Minecraft command",cmd))
            Toast.makeText(this,"کپی شد: $cmd  • چت بازی را باز کن و Paste/Send بزن",Toast.LENGTH_LONG).show()
        }
        button("⏱ تست هشدار زره") { Toast.makeText(this,"زره‌هات رو چک کن! 🛡",Toast.LENGTH_LONG).show() }
        button("بستن پنل") { hidePanel() }
        panel=box
        wm.addView(box, params(prefs.getInt("panel_x",82),prefs.getInt("panel_y",220),260,WindowManager.LayoutParams.WRAP_CONTENT))
    }

    private fun hidePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel=null
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        hidePanel()
        listOf(bubble, armorView).forEach { v -> v?.let { try { wm.removeView(it) } catch (_: Exception) {} } }
        bubble=null; armorView=null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
